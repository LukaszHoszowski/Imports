print('demo_reader is being imported')
